var N =6
var divsor1=1
var divisor2= 2
divisor3=3
if(N==divsor1+divisor2+divisor3) {}
console.log("o numero é perfeito")