Reais= [1, 3, 7, 15, 9, 987, 3456, 2345, 384512, 2468957888]
var Maior=0
var Menor=Reais[1]
for (i = 0; i < Reais.length; i++) {
    if(Maior<Reais[i])
    {
        Maior=Reais[i]
    }  
    
    if(Menor>Reais[i])
    {
        Menor=Reais[i]
    } 
}
console.log("O Menor é: "+Menor)
console.log("O Maior é: "+Maior)
