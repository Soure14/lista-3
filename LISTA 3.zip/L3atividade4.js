var deno=1
var soma=0
for(i=1; i<=50; i++)
{
    soma= soma+(deno/i)
    deno=deno+2   
}
console.log(soma)