var valor_copia=9
var Total=10
for(i=1; i<=Total; i++)
{
    console.log(i+"x"+Total+"="+(i*valor_copia))
}