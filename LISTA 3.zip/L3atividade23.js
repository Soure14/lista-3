var valor_multiplicado=2
var Total=2
for(i=1; i<=10; i++)
{
    console.log(i+"x"+Total+"="+(i*Total))
}