var valor_copia=0.06
var Total=200
for(i=1; i<=Total; i++)
{
    console.log(i+"x"+Total+"="+(i*valor_copia))
}